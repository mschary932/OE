//
//  SignaturePainterViewController.h
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignaturePainterView.h"

@protocol SignaturePainterViewControllerDelegate;

@interface SignaturePainterViewController : UIViewController
@property (nonatomic, assign) id<SignaturePainterViewControllerDelegate> delegate;
@property (nonatomic, assign, readonly) SignaturePainterView *painterView;

@property(nonatomic,assign) CGFloat                     strokeWidth;
@property(nonatomic,retain) NSString                    *strokeColor;
@property(nonatomic,assign) BOOL                        showClearButton;   //If YES clear button to clear, else if NO long tap to clear
@property(nonatomic,assign) BOOL                        shakeToClearEnabled;

@end


@protocol SignaturePainterViewControllerDelegate <NSObject>
@optional
- (void)signaturePainterDidCancel:(SignaturePainterViewController *)painter;
- (void)signaturePainterDidFinishDrawing:(SignaturePainterViewController *)painter;
@end