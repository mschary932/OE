//
//  SignaturePainterView.m
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>

#import "SignaturePainterView.h"
#import "UIColor+HexString.h"
#import "NSData+Base64.h"

#define kClearButtonWidth     45
#define kClearButtonHeight    30


@interface SignaturePainterView (){
   CGPoint         _previousPoint;
}

@property (nonatomic,retain) UIBezierPath *path;
@property (nonatomic,retain) UIButton *clearButton;

- (void)erase;
- (CGPoint) midPointFromPoint1:(CGPoint)p1 andPoint2:(CGPoint)p2;

@end

@implementation SignaturePainterView

- (id) init {
    self = [super init];
    if(self) {
        self.path               = [UIBezierPath bezierPath];
        self.backgroundColor    = [UIColor whiteColor];
        [self becomeFirstResponder];
        self.clearButton        = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [self.clearButton setTitle:@"Clear" forState:UIControlStateNormal];
        [self.clearButton addTarget:self action:@selector(erase) forControlEvents:UIControlEventTouchUpInside];
        self.clearButton.hidden = YES;
        [self addSubview:self.clearButton];
    }
    return self;
}

- (void) setShowClearButton:(BOOL)showClearButton {
    _showClearButton = showClearButton;
   self.clearButton.hidden = !showClearButton;
}

- (void) setStrokeColor:(NSString *)strokeColor {
    if(strokeColor==_strokeColor) return;
    
    strokeColor     = [strokeColor stringByReplacingOccurrencesOfString:@"#" withString:@""];
    [strokeColor retain];
    [_strokeColor release];
    _strokeColor = strokeColor;
}

- (void)erase {
    self.path   = nil;
    self.path   = [UIBezierPath bezierPath];
    [self setNeedsDisplay];
}

- (BOOL) canBecomeFirstResponder {
    return YES;
}

- (void) layoutSubviews {
    if(self.clearButton) {
        self.clearButton.frame = CGRectMake(self.frame.size.width-kClearButtonWidth,
                                            self.frame.size.height-kClearButtonHeight,
                                            kClearButtonWidth,
                                            kClearButtonHeight);
        self.clearButton.layer.frame = self.clearButton.frame;
    }
}

- (void)motionEnded:(UIEventSubtype)motion withEvent:(UIEvent *)event {
    // For shake motion
    if (event.subtype == UIEventSubtypeMotionShake){
        [self erase];
    }
    [super motionEnded:motion withEvent:event];
}

- (CGPoint) midPointFromPoint1:(CGPoint)p1 andPoint2:(CGPoint)p2 {
    return (CGPoint) {
        (p1.x + p2.x) / 2.0,
        (p1.y + p2.y) / 2.0
    };
}

- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch          = [touches anyObject];
    CGPoint currentPoint    = [touch locationInView:self];
    _previousPoint          = currentPoint;
    [self.path moveToPoint:currentPoint];
}

- (void) touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch              = [touches anyObject];
    CGPoint currentPoint        = [touch locationInView:self];
    CGPoint midpoint            = [self midPointFromPoint1:_previousPoint andPoint2:currentPoint];
    [self.path addQuadCurveToPoint:midpoint controlPoint:_previousPoint];
    [self setNeedsDisplay];
    _previousPoint              = currentPoint;
}

- (void) touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    // Nothing to do on touches ended.
}

- (void)drawRect:(CGRect)rect
{
    [[UIColor colorWithHexString:self.strokeColor] setStroke];
    self.path.lineWidth = self.strokeWidth;
    [self.path stroke];
}

- (NSString*) getSignatureImageBase64 {
    UIImage *image = [self getSignatureImage];
    NSData *imageData = UIImagePNGRepresentation(image);
    return [imageData base64EncodedString];
}

- (UIImage*) getSignatureImage {
    
    self.clearButton.hidden     = YES;
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, NO, 0);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
    // Get the image out of the context
    UIImage *signatureImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    if(self.showClearButton) {
        self.clearButton.hidden = NO;
    }
    
    return signatureImage;
}

- (void) dealloc {
    [self resignFirstResponder];
    [_path release];
    [super dealloc];
}


@end
