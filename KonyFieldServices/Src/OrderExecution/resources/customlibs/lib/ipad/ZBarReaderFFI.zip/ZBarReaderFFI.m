//
//  ZBarReaderFFI.m
//  VMAppWithKonylib
//
//  Created by Phaneendra Vakalapudi on 3/4/15.
//
//

#import "ZBarReaderFFI.h"
#import "CallBack.h"

@implementation ZBarReaderFFI
@synthesize scannedBarCode;
@synthesize fnCallback;

-(void)zbarStartScanWithCallback:(CallBack *)fn_Callback{
    scannedBarCode = nil;
    self.fnCallback = fn_Callback;
    ZBarReaderViewController *reader = [ZBarReaderViewController new];
    reader.readerDelegate = self;
    reader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = reader.scanner;
    
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    
    UINavigationController* navigationController = (UINavigationController *)[[[[[[[UIApplication sharedApplication] keyWindow] subviews] objectAtIndex:0] subviews] objectAtIndex:0] delegate];
    
    [navigationController performSelectorOnMainThread:@selector(presentModalViewController:animated:) withObject:reader waitUntilDone:NO];
    
    [reader release];
}

// Delegate methods for UIImagePickerController
- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    // ADD: get the decode results
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // EXAMPLE: just grab the first barcode
        break;
    
    NSLog(@"Scanned barcode: %@",symbol.data);
    scannedBarCode = [symbol.data copyWithZone:NULL];
    // EXAMPLE: do something useful with the barcode image
    //resultImage.image =
    //[info objectForKey: UIImagePickerControllerOriginalImage];
    
    // ADD: dismiss the controller (NB dismiss from the *reader*!)
    [reader dismissViewControllerAnimated:YES completion:nil];
    [fnCallback executeWithArguments:[NSArray arrayWithObject:scannedBarCode?scannedBarCode:nil]];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

// called when no barcode is found in an image selected by the user.
// if retry is NO, the delegate *must* dismiss the controller
- (void) readerControllerDidFailToRead: (ZBarReaderController*) reader
                             withRetry: (BOOL) retry {
    if (!retry) {
        [reader dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void) dealloc {
    if(scannedBarCode) [scannedBarCode release];
    [super dealloc];
}

@end
