//
//  ZBarReaderFFI.h
//  VMAppWithKonylib
//
//  Created by Phaneendra Vakalapudi on 3/4/15.
//
//

#import <Foundation/Foundation.h>
#import "ZBarSDK.h"
#import "CallBack.h"

@interface ZBarReaderFFI : NSObject <ZBarReaderDelegate>
{
    NSString *scannedBarCode;
    CallBack *fnCallback;
}

@property (nonatomic,retain) NSString *scannedBarCode;
@property (nonatomic,retain) CallBack *fnCallback;

@end
