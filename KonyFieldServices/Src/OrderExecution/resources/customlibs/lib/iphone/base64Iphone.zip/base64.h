//
//  base64.h
//  akhi
//
//  Created by FieldSales on 17/02/16.
//  Copyright (c) 2016 kony. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface base64ViewController : UIViewController

-(void) openBase64File:(NSString *)base64String WithFileNameAs:(NSString *)fileName;


@end
