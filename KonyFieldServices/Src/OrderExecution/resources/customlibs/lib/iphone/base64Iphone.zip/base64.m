//
//  base64.m
//  akhi
//
//  Created by FieldSales on 17/02/16.
//  Copyright (c) 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "base64.h"
#import "stdlib.h"
#import "lglobals.h"
#import "KonyUIContext.h"

@implementation base64ViewController

- (id)init {
    NSLog(@"$$$$$$$$$CALL STATE$$$$$ init method");
    return self;
}

-(void)openBase64File:(NSString *)base64String WithFileNameAs:(NSString *)fileName {
    NSLog(@"$$$$$$$$$CALL STATE$$$$$%@", fileName);
    NSData *base64Decodeddata = [[NSData alloc] initWithBase64EncodedString:base64String options:0];
    
    NSArray *searchPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentPath = [searchPaths objectAtIndex:0];
    fileName = [fileName stringByAppendingString:@".pdf"];
    NSString *filePath = [documentPath stringByAppendingPathComponent:fileName];
    BOOL success =[base64Decodeddata writeToFile:filePath atomically:YES];
    NSURL *url = [NSURL fileURLWithPath:filePath];
    
    NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
    UIWebView *webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [webView loadRequest: requestObj];
    webView.delegate = self;
    
    [self.view addSubview:webView];
}

@end


