#import "ViewController.h"

#import <LocalAuthentication/LocalAuthentication.h>
#import <CallBack.h>
@implementation ViewController

//This method will invoke the TouchId interface, validates the scanned input and returns the validation status code
+ (void)authenicateTouchId:(id)callBackObject dispMsg: (NSString *) msg
{
   LAContext *context = [[LAContext alloc] init];
    
    __block NSArray *res;
    __block NSError *error;
	// This will check whether the device has support for local authentication
    if ([context canEvaluatePolicy: LAPolicyDeviceOwnerAuthenticationWithBiometrics error:&error])
    {
		// This invokes the local authentication mechanism if it is enabled
       [context evaluatePolicy:LAPolicyDeviceOwnerAuthenticationWithBiometrics
				localizedReason:msg
                reply:^(BOOL success, NSError *error)
        {
           if (success) {
				res = [NSArray arrayWithObject:@"0"];
           }else{
				switch(error.code){
                    case LAErrorAuthenticationFailed:{
                        res = [NSArray arrayWithObject:@"1"];
                        break;
                    }
					case LAErrorUserCancel:{
						res = [NSArray arrayWithObject:@"2"];
						break;
					}
                    case LAErrorSystemCancel:{
                        res = [NSArray arrayWithObject:@"3"];
                        break;
                    }
                    case LAErrorUserFallback:{
                        res = [NSArray arrayWithObject:@"4"];
                        break;
                    }
                    case LAErrorPasscodeNotSet:{
                        res = [NSArray arrayWithObject:@"5"];
                        break;
                    }
                    case LAErrorTouchIDNotAvailable:{
                        res = [NSArray arrayWithObject:@"6"];
                        break;
                    }
                    case LAErrorTouchIDNotEnrolled:{
                        res = [NSArray arrayWithObject:@"7"];
                        break;
                    }
				}
				
			}
            [callBackObject executeWithArguments:res];
        }];
    }
    else
    {
        res = [NSArray arrayWithObject:@"-1"];
        [callBackObject executeWithArguments:res];
    }
}
@end