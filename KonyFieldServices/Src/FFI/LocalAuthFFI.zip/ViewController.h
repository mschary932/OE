//
//  ViewController.h
//  TouchIDExample

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
+(void) authenicateTouchId:(id)callBackObject dispMsg:(NSString *) msg;
@end